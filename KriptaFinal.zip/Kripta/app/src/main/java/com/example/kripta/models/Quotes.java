package com.example.kripta.models;

public class Quotes {

    USD USD;

    public com.example.kripta.models.USD getUSD() {
        return USD;
    }

    public void setUSD(com.example.kripta.models.USD USD) {
        this.USD = USD;
    }
}
